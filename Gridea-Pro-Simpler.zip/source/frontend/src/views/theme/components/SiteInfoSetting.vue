<template>
  <div class="pb-20 max-w-4xl mx-auto pt-4">
    <div class="space-y-6">
      <!-- Site Name -->
      <div class="grid grid-cols-[180px_1fr] items-center gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground">{{ $t('settings.basic.siteName') }}</label>
        <div class="max-w-sm">
          <Input v-model="form.siteName" />
        </div>
      </div>

      <!-- Site Description -->
      <div class="grid grid-cols-[180px_1fr] items-start gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground pt-2">{{ $t('settings.basic.siteDescription')
        }}</label>
        <div class="max-w-sm">
          <Textarea v-model="form.siteDescription" rows="3" />
          <div class="text-xs text-muted-foreground mt-1">{{ $t('article.htmlSupport') }}</div>
        </div>
      </div>

      <!-- Site Author -->
      <div class="grid grid-cols-[180px_1fr] items-center gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground">{{ $t('settings.basic.siteAuthor')
        }}</label>
        <div class="max-w-sm">
          <Input v-model="form.siteAuthor" />
        </div>
      </div>

      <!-- Site Email -->
      <div class="grid grid-cols-[180px_1fr] items-center gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground">{{ $t('settings.basic.siteEmail') }}</label>
        <div class="max-w-sm">
          <Input v-model="form.siteEmail" />
        </div>
      </div>

      <!-- Site Language -->
      <div class="grid grid-cols-[180px_1fr] items-start gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground pt-2">{{ $t('settings.basic.siteLanguage')
          }}</label>
        <div class="max-w-sm">
          <Select v-model="form.siteLanguage">
            <SelectTrigger>
              <SelectValue :placeholder="$t('settings.basic.siteLanguage')" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="zh-cn">简体中文</SelectItem>
              <SelectItem value="zh-tw">繁体中文</SelectItem>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="ja">日本語</SelectItem>
              <SelectItem value="ko">한국어</SelectItem>
              <SelectItem value="fr">Français</SelectItem>
              <SelectItem value="de">Deutsch</SelectItem>
              <SelectItem value="es">Español</SelectItem>
            </SelectContent>
          </Select>
          <div class="text-xs text-muted-foreground mt-1 text-left">{{ $t('settings.basic.siteLanguageDesc') }}</div>
        </div>
      </div>

      <!-- Footer Info -->
      <div class="grid grid-cols-[180px_1fr] items-start gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground pt-2">{{ $t('settings.basic.footerInfo')
        }}</label>
        <div class="max-w-sm">
          <Textarea v-model="form.footerInfo" rows="3" placeholder="Powered by Gridea Pro" />
          <div class="text-xs text-muted-foreground mt-1">{{ $t('article.htmlSupport') }}</div>
        </div>
      </div>

      <!-- Favicon -->
      <div class="grid grid-cols-[180px_1fr] items-start gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground pt-2">{{ $t('settings.basic.favicon')
        }}</label>
        <div class="max-w-sm">
          <div
            class="w-24 h-24 border-1 border-dashed border-input rounded-lg flex items-center justify-center cursor-pointer hover:border-primary transition-colors relative overflow-hidden bg-background"
            @click="pickFavicon">
            <img v-if="faviconPath" :src="faviconPath" class="w-full h-full object-cover" />
            <div v-else class="flex flex-col items-center text-muted-foreground">
              <i class="ri-add-line text-2xl mb-1"></i>
              <span class="text-xs">Upload</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Avatar -->
      <div class="grid grid-cols-[180px_1fr] items-start gap-4">
        <label class="text-sm font-medium text-right text-muted-foreground pt-2">{{ $t('settings.basic.avatar')
        }}</label>
        <div class="max-w-sm">
          <div
            class="w-24 h-24 border-1 border-dashed border-input rounded-lg flex items-center justify-center cursor-pointer hover:border-primary transition-colors relative overflow-hidden bg-background"
            @click="pickAvatar">
            <img v-if="avatarPath" :src="avatarPath" class="w-full h-full object-cover" />
            <div v-else class="flex flex-col items-center text-muted-foreground">
              <i class="ri-add-line text-2xl mb-1"></i>
              <span class="text-xs">Upload</span>
            </div>
          </div>
        </div>
      </div>

    </div>

    <footer-box>
      <div class="flex justify-end w-full">
        <Button
variant="default"
          class="w-18 h-8 text-xs justify-center rounded-full bg-primary text-background hover:bg-primary/90 cursor-pointer"
          @click="saveTheme">
          {{ $t('common.save') }}
        </Button>
      </div>
    </footer-box>
  </div>
</template>

<script lang="ts" setup>
import { reactive, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { useSiteStore } from '@/stores/site'
import { toast } from 'vue-sonner'
import FooterBox from '@/components/FooterBox/index.vue'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import ga from '@/helpers/analytics'
import { EventsEmit, EventsOnce } from '@/wailsjs/runtime'
import { SaveFavicon, SaveAvatar } from '@/wailsjs/go/facade/SettingFacade'
import { SaveThemeConfigFromFrontend } from '@/wailsjs/go/facade/ThemeFacade'
import { domain } from '@/wailsjs/go/models'

const { t } = useI18n()
const siteStore = useSiteStore()

// Favicon & Avatar Logic
const faviconPath = ref('')
const avatarPath = ref('')

const toFileUrl = (p: string) => `/local-file?path=${encodeURIComponent(p)}&t=${Date.now()}`

const updateMediaPaths = () => {
  faviconPath.value = toFileUrl(`${siteStore.site.appDir}/favicon.ico`)
  avatarPath.value = toFileUrl(`${siteStore.site.appDir}/images/avatar.png`)
}

const pickFavicon = async () => {
  try {
    const defaultPath = await (window as any).go.app.App.OpenImageDialog()
    if (!defaultPath) return

    await SaveFavicon(defaultPath)
    updateMediaPaths()
    toast.success(t('settings.basic.faviconSaved'))
  } catch (e) {
    console.error(e)
    toast.error(t('settings.theme.uploadFailed'))
  }
}

const pickAvatar = async () => {
  try {
    const defaultPath = await (window as any).go.app.App.OpenImageDialog()
    if (!defaultPath) return

    await SaveAvatar(defaultPath)
    updateMediaPaths()
    toast.success(t('settings.basic.avatarSaved'))
  } catch (e) {
    console.error(e)
    toast.error(t('settings.theme.uploadFailed'))
  }
}

// Form Logic
const form = reactive({
  siteName: '',
  siteAuthor: '',
  siteEmail: '',
  siteLanguage: '',
  siteDescription: '',
  footerInfo: '',
})

const saveTheme = async () => {
  console.log('开始保存站点信息')

  // Construct full config to save
  const fullConfig = new domain.ThemeConfig({
    ...siteStore.site.themeConfig,
    siteName: form.siteName,
    siteAuthor: form.siteAuthor,
    siteEmail: form.siteEmail,
    language: form.siteLanguage,
    siteDescription: form.siteDescription,
    footerInfo: form.footerInfo,
  })

  try {
    await SaveThemeConfigFromFrontend(fullConfig)
    toast.success(t('settings.theme.configSaved'))
    ga('Theme', 'SiteInfo - save', form.siteName)
    EventsEmit('app-site-reload')
  } catch (e) {
    console.error(e)
    toast.error(t('settings.theme.saveFailed'))
  }
}

onMounted(() => {
  const config = siteStore.site.themeConfig
  form.siteName = config.siteName
  form.siteAuthor = config.siteAuthor
  form.siteEmail = config.siteEmail || ''
  form.siteLanguage = config.language || 'zh-cn'
  form.siteDescription = config.siteDescription
  form.footerInfo = config.footerInfo

  updateMediaPaths()
})
</script>
