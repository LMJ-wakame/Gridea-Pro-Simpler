<template>
    <Sheet v-model:open="openModel">
        <SheetContent side="right" class="w-[400px] sm:max-w-md p-0 gap-0 flex flex-col">
            <SheetHeader class="px-6 py-6 border-b">
                <SheetTitle>{{ $t('article.settings') }}</SheetTitle>
            </SheetHeader>

            <div class="relative flex-1 px-6 py-6 space-y-6 overflow-y-auto">
                <!-- URL -->
                <div class="space-y-2">
                    <Label>URL</Label>
                    <div class="flex gap-2">
                        <Input v-model="form.fileName" class="flex-1"
                            @change="(e: any) => $emit('fileNameChange', e)" />
                        <Button variant="outline" size="icon"
                            class="shrink-0 size-10 border-primary/20 text-primary/60 hover:text-primary hover:bg-primary/5 cursor-pointer"
                            :disabled="isGeneratingSlug"
                            :title="$t('settings.ai.generateSlug')"
                            @click="$emit('generateSlug')">
                            <SparklesIcon v-if="!isGeneratingSlug" class="size-4" />
                            <svg v-else class="size-4 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                            </svg>
                        </Button>
                    </div>
                </div>

                <div class="space-y-2">
                    <Label for="post-collection">Collection</Label>
                    <Input id="post-collection" v-model="form.collection" list="collection-options" placeholder="No collection" />
                    <datalist id="collection-options"><option v-for="name in collectionNames" :key="name" :value="name" /></datalist>
                    <p class="text-xs text-muted-foreground">Choose an existing name or enter a new one. Leave empty for no collection.</p>
                </div>
                <details class="space-y-3 border-t pt-4">
                    <summary class="cursor-pointer text-sm font-semibold">Another version <span v-if="form.versions.length">({{ form.versions.length }})</span></summary>
                    <p class="text-xs text-muted-foreground">Write your own translations in Markdown. Only versions with content appear on the published page. Saving the article saves all versions.</p>
                    <div v-for="(version, index) in form.versions" :key="index" class="space-y-3 rounded-md border p-3">
                        <Label :for="'version-language-' + index">Language</Label>
                        <select :id="'version-language-' + index" v-model="version.language" class="h-9 w-full rounded-md border bg-background px-3 text-sm">
                            <option v-for="language in versionLanguages" :key="language.code" :value="language.code" :disabled="form.versions.some((v, i) => i !== index && v.language === language.code)">{{ language.label }}</option>
                        </select>
                        <Label :for="'version-title-' + index">Title</Label>
                        <Input :id="'version-title-' + index" v-model="version.title" placeholder="Leave empty to use the original title" />
                        <Label :for="'version-content-' + index">Content (Markdown)</Label>
                        <textarea :id="'version-content-' + index" v-model="version.content" rows="14" class="w-full resize-y rounded-md border bg-background p-3 font-mono text-sm leading-relaxed" placeholder="Write this version here…" />
                        <Button type="button" variant="outline" size="sm" @click="removeVersion(index)">Remove version</Button>
                    </div>
                    <Button type="button" variant="outline" size="sm" :disabled="form.versions.length >= versionLanguages.length" @click="addVersion">Add another version</Button>
                </details>
                <!-- Categories -->
                <div class="space-y-2">
                    <Label>{{ $t('nav.category') }}</Label>
                    <Select v-model="form.categoryId" @update:model-value="onCategoryChange">
                        <SelectTrigger class="w-full">
                            <SelectValue :placeholder="$t('memo.selectCategory')" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="_none_">-</SelectItem>
                            <SelectItem v-for="c in availableCategories" :key="c.id" :value="c.id">{{ c.name }}
                            </SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                <!-- Tags -->
                <div class="space-y-2">
                    <Label>{{ $t('nav.tag') }}</Label>
                    <div>
                        <div class="flex flex-wrap gap-2 p-2 border rounded-md bg-background min-h-[32px] mb-2">
                            <span v-for="tag in form.tags" :key="tag"
                                class="inline-flex items-center px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-xs text-primary/80">
                                {{ tag }}
                                <button class="ml-1 text-primary/60 hover:text-destructive"
                                    @click="$emit('removeTag', tag)">
                                    <XMarkIcon class="size-3" />
                                </button>
                            </span>
                            <input :value="tagInput"
                                class="flex-1 min-w-[80px] bg-transparent outline-none text-foreground text-sm px-1"
                                placeholder="Add tag..."
                                @input="$emit('update:tagInput', ($event.target as HTMLInputElement).value)"
                                @keydown.enter.prevent="$emit('addTag')" />
                        </div>
                        <div class="flex flex-wrap gap-2 max-h-[120px] overflow-y-auto p-1 border rounded-md">
                            <span v-for="t in availableTags" :key="t"
                                class="cursor-pointer text-xs px-2 py-1 rounded-full bg-primary/5 hover:bg-primary/15 border border-primary/10 transition-colors select-none text-muted-foreground"
                                @click="$emit('selectTag', t)">
                                {{ t }}
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Date -->
                <div class="space-y-2">
                    <Label>{{ $t('article.createAt') }}</Label>
                    <Popover>
                        <PopoverTrigger as-child>
                            <Button variant="outline" :class="cn(
                                'w-full justify-start text-left font-normal hover:bg-primary/5 hover:text-primary border-primary/20 cursor-pointer',
                                !dateValue && 'text-muted-foreground',
                            )">
                                <CalendarIcon class="mr-2 h-4 w-4" />
                                {{ (form.createdAt && form.createdAt.isValid()) ? form.createdAt.format('YYYY-MM-DD HH:mm:ss') : $t('article.createAt') }}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent class="w-auto p-0" align="start">
                            <Calendar :model-value="(dateValue as any)" show-week-number
                                @update:model-value="(val: any) => $emit('update:dateValue', val)" />
                            <div class="border-t p-3">
                                <div class="relative">
                                    <ClockIcon class="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground z-10" />
                                    <Input v-model="dateTimeDraft" placeholder="YYYY-MM-DD HH:mm:ss"
                                        class="h-9 pl-9 selection:bg-primary selection:text-primary-foreground"
                                        @blur="commitDateTime" @keyup.enter="commitDateTime" />
                                </div>
                            </div>
                        </PopoverContent>
                    </Popover>
                </div>

                <!-- Feature Image -->
                <div class="space-y-2">
                    <Label>{{ $t('article.featureImage') }}</Label>
                    <div class="space-y-2">
                        <Input :model-value="featureDisplayValue"
                            :placeholder="$t('article.featureImagePlaceholder') || 'Image URL or Local Path'"
                            @update:model-value="(val: any) => $emit('update:featureDisplayValue', val as string)" />

                        <div class="feature-uploader cursor-pointer border border-dashed rounded-md p-4 text-center hover:border-primary transition-colors bg-background"
                            @click="$emit('selectFeatureImage')">
                            <div v-if="featureImagePreviewSrc">
                                <img class="feature-image mx-auto max-h-[150px] object-cover rounded-md"
                                    :src="featureImagePreviewSrc" />
                            </div>
                            <div v-else>
                                <img src="@/assets/images/image_upload.svg" class="upload-img mx-auto w-20">
                                <i class="ri-upload-2-line upload-icon text-lg mt-2 block text-muted-foreground"></i>
                                <div class="text-xs text-muted-foreground mt-2">{{ $t('article.selectLocalImage') }}</div>
                            </div>
                        </div>

                        <Button v-if="featureDisplayValue" variant="destructive" size="sm" class="mt-2 w-full"
                            @click.stop="$emit('clearFeatureImage')">
                            <template #icon>
                                <TrashIcon class="size-4 mr-2" />
                            </template>
                            {{ $t('common.delete') }}
                        </Button>
                    </div>
                </div>

                <!-- Hide in List -->
                <div class="flex items-center justify-between">
                    <Label>{{ $t('article.hideInList') }}</Label>
                    <Switch v-model:checked="form.hideInList" size="sm" />
                </div>

                <!-- Top Article -->
                <div class="flex items-center justify-between">
                    <Label>{{ $t('article.top') }}</Label>
                    <Switch v-model:checked="form.isTop" size="sm" />
                </div>
            </div>

            <SheetFooter class="flex-shrink-0 px-6 py-4 border-t gap-3">
                <Button variant="outline"
                    class="w-18 h-8 text-xs justify-center rounded-full border border-primary/20 text-primary/80 hover:bg-primary/5 hover:text-primary cursor-pointer"
                    @click="openModel = false">
                    {{ $t('common.cancel') }}
                </Button>
                <Button variant="default"
                    class="w-18 h-8 text-xs justify-center rounded-full bg-primary text-background hover:bg-primary/90 cursor-pointer"
                    @click="$emit('confirmPublish')">
                    {{ $t('article.publish') }}
                </Button>
            </SheetFooter>
        </SheetContent>
    </Sheet>
</template>

<script lang="ts" setup>
import { computed, ref, watch, nextTick } from 'vue'
import { cn } from '@/lib/utils'
import { useSiteStore } from '@/stores/site'
const collectionSite = useSiteStore()
const collectionNames = computed(() => [...new Set(collectionSite.posts.map(p => p.collection || '').filter(Boolean))].sort())
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Calendar } from '@/components/ui/calendar'
import { Sheet, SheetContent, SheetTitle, SheetHeader, SheetFooter } from '@/components/ui/sheet'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CalendarIcon, ClockIcon, TrashIcon, XMarkIcon, SparklesIcon } from '@heroicons/vue/24/outline'
import type { DateValue } from '@internationalized/date'
import type { ArticleFormState } from '../composables/useArticleForm'

const props = defineProps<{
    open: boolean
    form: ArticleFormState
    tagInput: string
    availableTags: string[]
    availableCategories: { id: string; name: string; slug: string }[]  // 分类对象列表
    dateValue: DateValue
    dateTimeValue: string
    featureDisplayValue: string
    featureImagePreviewSrc: string
    isGeneratingSlug?: boolean
}>()

const emit = defineEmits<{
    'update:open': [value: boolean]
    'update:tagInput': [value: string]
    'update:dateValue': [value: DateValue]
    'update:dateTimeValue': [value: string]
    'update:featureDisplayValue': [value: string]
    addTag: []
    removeTag: [tag: string]
    selectTag: [tag: string]
    fileNameChange: [event: Event]
    selectFeatureImage: []
    clearFeatureImage: []
    confirmPublish: []
    generateSlug: []
}>()

const versionLanguages = [
    { code: 'en', label: 'English (ENG)' }, { code: 'zh', label: '中文 (CN)' },
    { code: 'ja', label: '日本語 (JA)' }, { code: 'ko', label: '한국어 (KO)' },
    { code: 'fr', label: 'Français (FR)' }, { code: 'de', label: 'Deutsch (DE)' },
    { code: 'es', label: 'Español (ES)' }, { code: 'pt', label: 'Português (PT)' },
    { code: 'ru', label: 'Русский (RU)' }, { code: 'it', label: 'Italiano (IT)' },
    { code: 'zh-Hant', label: '繁體中文' },
]
const addVersion = () => {
    const next = versionLanguages.find(l => !props.form.versions.some(v => v.language === l.code))
    if (next) props.form.versions.push({ language: next.code, title: '', content: '' })
}
const removeVersion = (index: number) => {
    const version = props.form.versions[index]
    if ((!version.title && !version.content) || window.confirm('Remove this language version? Save the article to apply.')) props.form.versions.splice(index, 1)
}

// 选择分类时同步更新 category（名称）和 categoryId（UUID）
const onCategoryChange = (id: string) => {
    if (id === '_none_') {
        props.form.category = ''
        props.form.categoryId = ''
    } else {
        const matched = props.availableCategories.find((c) => c.id === id)
        props.form.category = matched ? matched.name : id
        props.form.categoryId = id
    }
}

const openModel = computed({
    get: () => props.open,
    set: (val: boolean) => emit('update:open', val),
})

// 日期时间手动输入：用本地草稿承接输入中途的非法字符串，失焦/回车时才提交。
// 提交后用 nextTick 把草稿拉回 prop —— 合法则同步成规范化后的值，非法则回滚到上次有效值。
const dateTimeDraft = ref(props.dateTimeValue)
watch(() => props.dateTimeValue, (v) => { dateTimeDraft.value = v })
const commitDateTime = () => {
    emit('update:dateTimeValue', dateTimeDraft.value)
    nextTick(() => { dateTimeDraft.value = props.dateTimeValue })
}
</script>
